import java.util.Date;


public class CurrentDateTime {

	public static void main(String[] args) {
		Date d =  new Date();
		System.out.println(d);

	}

}
